#!/bin/sh
set -eu

# 目标机源码编译 cmg-native（安装脚本的回退路径）。

HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
DEST="${1:-$HERE/cmg-native}"

case "$(uname -m)" in
    armv7l|armv7)
        ARCH_FLAGS="-march=armv7-a -mfpu=vfpv3-d16 -mfloat-abi=hard"
        ;;
    aarch64|arm64)
        ARCH_FLAGS="-march=armv8-a"
        ;;
    *)
        echo "错误：不支持的架构：$(uname -m)" >&2
        exit 1
        ;;
esac

for tool in gcc g++ make; do
    if ! command -v "$tool" >/dev/null 2>&1; then
        echo "错误：缺少 $tool，编译 cmg-native 时需要它" >&2
        exit 1
    fi
done

make -C "$HERE/native-src" clean >/dev/null 2>&1 || true
make -C "$HERE/native-src" -j"$(getconf _NPROCESSORS_ONLN 2>/dev/null || echo 1)" cmg-native \
    CC=gcc \
    CXX=g++ \
    CFLAGS="-std=c11 -O2 -w -D_GNU_SOURCE" \
    CXXFLAGS="-std=c++17 -O2 -Wall -Wextra -Werror $ARCH_FLAGS" \
    STATIC_LDFLAGS="-static -pthread"
install -m 0755 "$HERE/native-src/cmg-native" "$DEST"
echo "==> cmg-native 编译完成：$DEST"
