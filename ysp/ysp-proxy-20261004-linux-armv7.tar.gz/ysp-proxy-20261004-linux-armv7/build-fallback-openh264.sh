#!/bin/sh
set -eu

# 目标机源码编译 OpenH264（安装脚本的回退路径）。

HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
SOURCE_TARBALL="${1:-$HERE/third_party/openh264-2.6.0.tar.gz}"
DEST="${2:-$HERE/libopenh264.so.8}"
OPENH264_VERSION=2.6.0
OPENH264_SHA256=558544ad358283a7ab2930d69a9ceddf913f4a51ee9bf1bfb9e377322af81a69

case "$(uname -m)" in
    armv7l|armv7)
        ARCH=arm
        ;;
    aarch64|arm64)
        ARCH=arm64
        ;;
    *)
        echo "错误：不支持的架构：$(uname -m)" >&2
        exit 1
        ;;
esac

for tool in gcc g++ make tar; do
    if ! command -v "$tool" >/dev/null 2>&1; then
        echo "错误：缺少 $tool，编译 OpenH264 时需要它" >&2
        exit 1
    fi
done
# 源码包不随安装包分发，缺失时才下载到本地，避免安装包超过 25 MB。
if [ ! -f "$SOURCE_TARBALL" ]; then
    echo "==> OpenH264 源码包缺失，正在下载到 $SOURCE_TARBALL"
    mkdir -p "$(dirname "$SOURCE_TARBALL")"
    urls="${YSP_OPENH264_URL:-}"
    urls="$urls https://github.776512.xyz/https://github.com/cisco/openh264/archive/refs/tags/v$OPENH264_VERSION.tar.gz"
    urls="$urls https://codeload.github.com/cisco/openh264/tar.gz/refs/tags/v$OPENH264_VERSION"
    urls="$urls https://github.com/cisco/openh264/archive/refs/tags/v$OPENH264_VERSION.tar.gz"
    downloaded=0
    for url in $urls; do
        [ -n "$url" ] || continue
        if command -v curl >/dev/null 2>&1; then
            if curl -fL --retry 3 --connect-timeout 15 --max-time 600 -o "$SOURCE_TARBALL.part" "$url"; then
                downloaded=1
                break
            fi
        elif command -v wget >/dev/null 2>&1; then
            if wget -T 30 -O "$SOURCE_TARBALL.part" "$url"; then
                downloaded=1
                break
            fi
        else
            echo "错误：需要 curl 或 wget 才能下载 OpenH264 源码" >&2
            exit 1
        fi
    done
    if [ "$downloaded" -ne 1 ]; then
        rm -f "$SOURCE_TARBALL.part"
        echo "错误：OpenH264 源码包下载失败，可设置 YSP_OPENH264_URL 指向镜像地址" >&2
        exit 1
    fi
    mv "$SOURCE_TARBALL.part" "$SOURCE_TARBALL"
fi

if command -v sha256sum >/dev/null 2>&1; then
    actual=$(sha256sum "$SOURCE_TARBALL")
    actual=${actual%% *}
    if [ "$actual" != "$OPENH264_SHA256" ]; then
        echo "错误：OpenH264 源码包 SHA256 校验失败" >&2
        exit 1
    fi
else
    echo "警告：未找到 sha256sum，已跳过源码包校验" >&2
fi

tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT INT TERM
tar -xzf "$SOURCE_TARBALL" -C "$tmp"
src=$(find "$tmp" -maxdepth 1 -type d -name 'openh264-*' | head -n 1)
if [ -z "$src" ]; then
    echo "错误：未找到解压后的 OpenH264 源码目录" >&2
    exit 1
fi

make -C "$src" -j"$(getconf _NPROCESSORS_ONLN 2>/dev/null || echo 1)" libraries \
    ARCH="$ARCH" \
    CC=gcc \
    CXX=g++ \
    AR=ar \
    USE_ASM=Yes
if [ ! -e "$src/libopenh264.so.8" ]; then
    echo "错误： OpenH264 编译未成功生成 libopenh264.so.8" >&2
    exit 1
fi
install -m 0755 "$src/libopenh264.so.8" "$DEST"
echo "==> OpenH264 编译完成：$DEST"
