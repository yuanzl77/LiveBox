// Persistent native helper for the existing JSONL CMG decoder protocol.
//
// The decoder core owns one wasm2c-backed session, so this process handles
// requests serially. Go can still prepare several lanes; decode calls wait for
// the one decoder instead of corrupting each other's session state.

#include "cmg_native.h"

#include <cctype>
#include <cerrno>
#include <cstdint>
#include <cstdio>
#ifndef _WIN32
#include <unistd.h>
#endif
#include <cstdlib>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <memory>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

namespace {

class Json {
 public:
  enum class Type { Null, Bool, Number, String, Array, Object };

  Json() : type_(Type::Null) {}

  static Json parse(const std::string& text) {
    size_t pos = 0;
    Json value = parseValue(text, pos);
    skipSpace(text, pos);
    if (pos != text.size()) fail("trailing JSON data");
    return value;
  }

  bool isBool() const { return type_ == Type::Bool; }
  bool isNumber() const { return type_ == Type::Number; }
  bool isString() const { return type_ == Type::String; }
  bool isArray() const { return type_ == Type::Array; }
  bool isObject() const { return type_ == Type::Object; }

  bool asBool() const {
    if (!isBool()) fail("expected bool");
    return bool_value_;
  }

  int64_t asInt64() const {
    if (!isNumber()) fail("expected number");
    errno = 0;
    char* end = nullptr;
    const long long value = std::strtoll(number_.c_str(), &end, 10);
    if (errno != 0 || end == number_.c_str() || *end != '\0') {
      fail("invalid integer");
    }
    return static_cast<int64_t>(value);
  }

  const std::string& asString() const {
    if (!isString()) fail("expected string");
    return string_;
  }

  const std::vector<Json>& asArray() const {
    if (!isArray()) fail("expected array");
    return items_;
  }

  const Json* get(const std::string& key) const {
    if (!isObject()) return nullptr;
    for (size_t i = 0; i < keys_.size(); ++i) {
      if (keys_[i] == key) return values_[i].get();
    }
    return nullptr;
  }

 private:
  Type type_ = Type::Null;
  bool bool_value_ = false;
  std::string number_;
  std::string string_;
  std::vector<std::string> keys_;
  std::vector<std::shared_ptr<Json>> values_;
  std::vector<Json> items_;

  [[noreturn]] static void fail(const char* message) { throw std::runtime_error(message); }

  static void skipSpace(const std::string& text, size_t& pos) {
    while (pos < text.size() && std::isspace(static_cast<unsigned char>(text[pos]))) {
      ++pos;
    }
  }

  static void expect(const std::string& text, size_t& pos, char wanted) {
    if (pos >= text.size() || text[pos] != wanted) fail("unexpected JSON character");
    ++pos;
  }

  static Json parseValue(const std::string& text, size_t& pos) {
    skipSpace(text, pos);
    if (pos >= text.size()) fail("unexpected end of JSON");
    const char ch = text[pos];
    if (ch == '{') return parseObject(text, pos);
    if (ch == '[') return parseArray(text, pos);
    if (ch == '"') return parseString(text, pos);
    if (ch == 't' || ch == 'f') return parseBool(text, pos);
    if (ch == 'n') return parseNull(text, pos);
    return parseNumber(text, pos);
  }

  static Json parseObject(const std::string& text, size_t& pos) {
    Json object;
    object.type_ = Type::Object;
    expect(text, pos, '{');
    skipSpace(text, pos);
    if (pos < text.size() && text[pos] == '}') {
      ++pos;
      return object;
    }
    while (true) {
      skipSpace(text, pos);
      if (pos >= text.size() || text[pos] != '"') fail("expected object key");
      Json key = parseString(text, pos);
      skipSpace(text, pos);
      expect(text, pos, ':');
      Json value = parseValue(text, pos);
      object.keys_.push_back(std::move(key.string_));
      object.values_.push_back(std::make_shared<Json>(std::move(value)));
      skipSpace(text, pos);
      if (pos >= text.size()) fail("unterminated object");
      if (text[pos] == ',') {
        ++pos;
        continue;
      }
      expect(text, pos, '}');
      return object;
    }
  }

  static Json parseArray(const std::string& text, size_t& pos) {
    Json array;
    array.type_ = Type::Array;
    expect(text, pos, '[');
    skipSpace(text, pos);
    if (pos < text.size() && text[pos] == ']') {
      ++pos;
      return array;
    }
    while (true) {
      array.items_.push_back(parseValue(text, pos));
      skipSpace(text, pos);
      if (pos >= text.size()) fail("unterminated array");
      if (text[pos] == ',') {
        ++pos;
        continue;
      }
      expect(text, pos, ']');
      return array;
    }
  }

  static Json parseString(const std::string& text, size_t& pos) {
    Json value;
    value.type_ = Type::String;
    expect(text, pos, '"');
    std::string out;
    while (pos < text.size()) {
      const unsigned char ch = static_cast<unsigned char>(text[pos++]);
      if (ch == '"') {
        value.string_ = std::move(out);
        return value;
      }
      if (ch != '\\') {
        out.push_back(static_cast<char>(ch));
        continue;
      }
      if (pos >= text.size()) fail("unterminated escape");
      const char escape = text[pos++];
      switch (escape) {
        case '"': out.push_back('"'); break;
        case '\\': out.push_back('\\'); break;
        case '/': out.push_back('/'); break;
        case 'b': out.push_back('\b'); break;
        case 'f': out.push_back('\f'); break;
        case 'n': out.push_back('\n'); break;
        case 'r': out.push_back('\r'); break;
        case 't': out.push_back('\t'); break;
        case 'u': {
          if (pos + 4 > text.size()) fail("short unicode escape");
          uint32_t code = 0;
          for (int i = 0; i < 4; ++i) {
            code = (code << 4) | hexValue(text[pos++]);
          }
          appendUtf8(out, code);
          break;
        }
        default: fail("unknown JSON escape");
      }
    }
    fail("unterminated string");
    return Json();
  }

  static unsigned hexValue(char ch) {
    if (ch >= '0' && ch <= '9') return static_cast<unsigned>(ch - '0');
    if (ch >= 'a' && ch <= 'f') return static_cast<unsigned>(ch - 'a' + 10);
    if (ch >= 'A' && ch <= 'F') return static_cast<unsigned>(ch - 'A' + 10);
    fail("invalid unicode escape");
    return 0;
  }

  static void appendUtf8(std::string& out, uint32_t code) {
    if (code <= 0x7f) {
      out.push_back(static_cast<char>(code));
    } else if (code <= 0x7ff) {
      out.push_back(static_cast<char>(0xc0 | (code >> 6)));
      out.push_back(static_cast<char>(0x80 | (code & 0x3f)));
    } else if (code <= 0xffff) {
      out.push_back(static_cast<char>(0xe0 | (code >> 12)));
      out.push_back(static_cast<char>(0x80 | ((code >> 6) & 0x3f)));
      out.push_back(static_cast<char>(0x80 | (code & 0x3f)));
    } else {
      out.push_back(static_cast<char>(0xf0 | (code >> 18)));
      out.push_back(static_cast<char>(0x80 | ((code >> 12) & 0x3f)));
      out.push_back(static_cast<char>(0x80 | ((code >> 6) & 0x3f)));
      out.push_back(static_cast<char>(0x80 | (code & 0x3f)));
    }
  }

  static Json parseBool(const std::string& text, size_t& pos) {
    Json value;
    value.type_ = Type::Bool;
    if (text.compare(pos, 4, "true") == 0) {
      value.bool_value_ = true;
      pos += 4;
    } else if (text.compare(pos, 5, "false") == 0) {
      value.bool_value_ = false;
      pos += 5;
    } else {
      fail("invalid boolean");
    }
    return value;
  }

  static Json parseNull(const std::string& text, size_t& pos) {
    if (text.compare(pos, 4, "null") != 0) fail("invalid null");
    pos += 4;
    return Json();
  }

  static Json parseNumber(const std::string& text, size_t& pos) {
    Json value;
    value.type_ = Type::Number;
    const size_t start = pos;
    if (pos < text.size() && text[pos] == '-') ++pos;
    while (pos < text.size()) {
      const char ch = text[pos];
      if (std::isdigit(static_cast<unsigned char>(ch)) || ch == 'e' || ch == 'E' ||
          ch == '+' || ch == '-' || ch == '.') {
        ++pos;
      } else {
        break;
      }
    }
    if (pos == start) fail("invalid number");
    value.number_ = text.substr(start, pos - start);
    return value;
  }
};

std::string jsonEscape(const std::string& value) {
  std::string out;
  out.reserve(value.size() + 8);
  for (const unsigned char ch : value) {
    switch (ch) {
      case '"': out += "\\\""; break;
      case '\\': out += "\\\\"; break;
      case '\b': out += "\\b"; break;
      case '\f': out += "\\f"; break;
      case '\n': out += "\\n"; break;
      case '\r': out += "\\r"; break;
      case '\t': out += "\\t"; break;
      default:
        if (ch < 0x20) {
          char buf[7];
          std::snprintf(buf, sizeof(buf), "\\u%04x", ch);
          out += buf;
        } else {
          out.push_back(static_cast<char>(ch));
        }
    }
  }
  return out;
}

struct Packed {
  std::vector<uint8_t> bytes;

  static void collect(void* user, uint32_t nal_index, uint32_t offset,
                      const uint8_t* data, uint32_t length) {
    auto* self = static_cast<Packed*>(user);
    uint8_t header[12];
    for (int i = 0; i < 4; ++i) header[i] = static_cast<uint8_t>(nal_index >> (8 * i));
    for (int i = 0; i < 4; ++i) header[4 + i] = static_cast<uint8_t>(offset >> (8 * i));
    for (int i = 0; i < 4; ++i) header[8 + i] = static_cast<uint8_t>(length >> (8 * i));
    self->bytes.insert(self->bytes.end(), header, header + 12);
    self->bytes.insert(self->bytes.end(), data, data + length);
  }

  void write(const std::filesystem::path& path) const {
    std::FILE* file = std::fopen(path.string().c_str(), "wb");
    if (!file) throw std::runtime_error("open changes file failed");
    const size_t written = std::fwrite(bytes.data(), 1, bytes.size(), file);
    const bool flushed = std::fflush(file) == 0;
#ifdef _WIN32
    const bool synced = flushed;
#else
    const bool synced = fsync(fileno(file)) == 0;
#endif
    std::fclose(file);
    if (written != bytes.size() || !flushed || !synced) {
      std::error_code ignored;
      std::filesystem::remove(path, ignored);
      throw std::runtime_error("changes file write failed");
    }
  }
};

struct Lane {
  bool busy = false;
  std::vector<uint8_t> es;
  std::vector<CmgNal> nals;
};

std::vector<uint8_t> readBinary(const std::string& path) {
  std::ifstream in(path, std::ios::binary | std::ios::ate);
  if (!in) throw std::runtime_error("read ES failed: " + path);
  const std::streamsize size = in.tellg();
  if (size < 0) throw std::runtime_error("ES size unavailable: " + path);
  std::vector<uint8_t> data(static_cast<size_t>(size));
  in.seekg(0, std::ios::beg);
  if (!in.read(reinterpret_cast<char*>(data.data()), size)) {
    throw std::runtime_error("short ES read: " + path);
  }
  return data;
}

int laneCount() {
  const char* raw = std::getenv("CMG_LANES");
  if (!raw) return 3;
  errno = 0;
  const long count = std::strtol(raw, nullptr, 10);
  if (errno != 0 || count < 1 || count > 8) return 3;
  return static_cast<int>(count);
}

std::filesystem::path changesDirectory() {
  if (const char* raw = std::getenv("CMG_CHANGES_DIR"); raw && *raw) {
    return std::filesystem::path(raw);
  }
  return std::filesystem::temp_directory_path();
}

std::string intJSON(int64_t value) { return std::to_string(value); }

std::string response(const Json& request, const std::string& payload) {
  const Json* id = request.get("id");
  return "{\"id\":" + (id ? intJSON(id->asInt64()) : std::string("0")) + "," + payload + "}";
}

std::string failJSON(const Json& request, const std::string& op, const std::string& error) {
  return response(request, "\"ok\":false,\"op\":\"" + jsonEscape(op) + "\",\"error\":\"" +
                               jsonEscape(error) + "\"");
}

std::string handlePrepare(const Json& request, std::vector<Lane>& lanes) {
  const Json* path_json = request.get("path");
  const Json* nals_json = request.get("nals");
  if (!path_json || !path_json->isString() || !nals_json || !nals_json->isArray()) {
    throw std::runtime_error("prepare requires path and nals");
  }
  const std::vector<uint8_t> es = readBinary(path_json->asString());
  std::vector<CmgNal> nals;
  nals.reserve(nals_json->asArray().size());
  for (const Json& item : nals_json->asArray()) {
    const Json* type = item.get("type");
    const Json* ps = item.get("ps");
    const Json* pe = item.get("pe");
    if (!type || !ps || !pe) throw std::runtime_error("NAL entry missing type/ps/pe");
    CmgNal nal{};
    nal.type = static_cast<uint32_t>(type->asInt64());
    nal.start = static_cast<uint32_t>(ps->asInt64());
    nal.end = static_cast<uint32_t>(pe->asInt64());
    nals.push_back(nal);
  }
  if (nals.empty()) throw std::runtime_error("empty NAL list");
  for (size_t i = 0; i < lanes.size(); ++i) {
    if (lanes[i].busy) continue;
    lanes[i] = Lane{};
    lanes[i].busy = true;
    lanes[i].es = std::move(es);
    lanes[i].nals = std::move(nals);
    return response(request, "\"ok\":true,\"op\":\"prepare\",\"lane\":" + intJSON(static_cast<int64_t>(i)));
  }
  throw std::runtime_error("all decoder lanes busy");
}

int64_t intMember(const Json& object, const char* key) {
  const Json* value = object.get(key);
  if (!value || !value->isNumber()) throw std::runtime_error(std::string("missing ") + key);
  return value->asInt64();
}

std::string handleDecode(const Json& request, std::vector<Lane>& lanes,
                         const std::filesystem::path& changes_dir) {
  const Json* lane_value = request.get("lane");
  const int64_t lane_id = lane_value ? lane_value->asInt64() : 0;
  if (lane_id < 0 || static_cast<size_t>(lane_id) >= lanes.size()) {
    throw std::runtime_error("bad lane");
  }
  Lane& lane = lanes[static_cast<size_t>(lane_id)];
  if (!lane.busy || lane.es.empty()) throw std::runtime_error("prepare was not called");

  const int64_t key_ms = intMember(request, "keyMS");
  const int64_t clock_ms = intMember(request, "clockMS");
  uint32_t changed_nals = 0;
  uint32_t video_nals = 0;
  uint32_t changed_bytes = 0;
  Packed packed;
  const int rc = cmg_native_decode(lane.es.data(), lane.es.size(), lane.nals.data(),
                                   lane.nals.size(), key_ms, clock_ms, &changed_nals,
                                   &video_nals, &changed_bytes, &Packed::collect, &packed);
  if (rc != 0 && rc != 3) {
    throw std::runtime_error("cmg_native_decode returned " + std::to_string(rc));
  }
  const bool complete = rc == 0;
  std::string changes_path;
  if (complete) {
    const Json* id = request.get("id");
    const std::filesystem::path path =
        changes_dir / ("changeRuns-" + (id ? intJSON(id->asInt64()) : std::string("0")) + ".bin");
    packed.write(path);
    changes_path = path.string();
  }
  return response(
      request,
      "\"ok\":true,\"op\":\"decode\",\"lane\":" + intJSON(lane_id) +
          ",\"complete\":" + (complete ? "true" : "false") +
          ",\"changedNALs\":" + intJSON(changed_nals) +
          ",\"videoNALs\":" + intJSON(video_nals) +
          ",\"changedBytes\":" + intJSON(changed_bytes) +
          ",\"changesPath\":\"" + jsonEscape(changes_path) + "\"");
}

std::string handleRelease(const Json& request, std::vector<Lane>& lanes) {
  const Json* lane_value = request.get("lane");
  const int64_t lane_id = lane_value ? lane_value->asInt64() : 0;
  if (lane_id < 0 || static_cast<size_t>(lane_id) >= lanes.size()) {
    throw std::runtime_error("bad lane");
  }
  lanes[static_cast<size_t>(lane_id)].busy = false;
  lanes[static_cast<size_t>(lane_id)].es.clear();
  lanes[static_cast<size_t>(lane_id)].es.shrink_to_fit();
  lanes[static_cast<size_t>(lane_id)].nals.clear();
  lanes[static_cast<size_t>(lane_id)].nals.shrink_to_fit();
  return response(request, "\"ok\":true,\"op\":\"release\",\"lane\":" + intJSON(lane_id));
}

std::string handleRequest(const Json& request, std::vector<Lane>& lanes,
                          const std::filesystem::path& changes_dir) {
  const Json* op = request.get("op");
  if (!op || !op->isString()) throw std::runtime_error("missing op");
  const std::string& operation = op->asString();
  if (operation == "prepare") return handlePrepare(request, lanes);
  if (operation == "decode") return handleDecode(request, lanes, changes_dir);
  if (operation == "release") return handleRelease(request, lanes);
  if (operation == "close") {
    std::cout << response(request, "\"ok\":true,\"op\":\"close\"") << '\n';
    std::flush(std::cout);
    std::exit(0);
  }
  throw std::runtime_error("unknown op: " + operation);
}

void writeReady() {
  std::cout << "{\"id\":0,\"ok\":true,\"op\":\"ready\"}\n";
  std::flush(std::cout);
}

}  // namespace

int main() {
  try {
    const int count = laneCount();
    std::vector<Lane> lanes(static_cast<size_t>(count));
    const std::filesystem::path changes_dir = changesDirectory();
    std::error_code error;
    std::filesystem::create_directories(changes_dir, error);
    if (error) throw std::runtime_error("create changes dir failed: " + error.message());
    writeReady();
    std::string line;
    while (std::getline(std::cin, line)) {
      if (line.empty()) continue;
      Json request;
      try {
        request = Json::parse(line);
      } catch (const std::exception& parse_error) {
        std::cout << "{\"id\":0,\"ok\":false,\"error\":\"" << jsonEscape(parse_error.what())
                  << "\"}\n";
        std::flush(std::cout);
        continue;
      }
      std::string output;
      try {
        output = handleRequest(request, lanes, changes_dir);
      } catch (const std::exception& request_error) {
        const Json* op = request.get("op");
        output = failJSON(request, op && op->isString() ? op->asString() : "",
                          request_error.what());
      }
      std::cout << output << '\n';
      std::flush(std::cout);
    }
    return 0;
  } catch (const std::exception& error) {
    std::cerr << "cmg-native-helper: " << error.what() << '\n';
    return 1;
  }
}
