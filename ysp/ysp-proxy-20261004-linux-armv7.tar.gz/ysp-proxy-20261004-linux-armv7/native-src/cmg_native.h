#ifndef YSP_CMG_NATIVE_H_
#define YSP_CMG_NATIVE_H_

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
#include <chrono>
extern "C" {
#endif

struct CmgNal {
  uint32_t type;
  uint32_t start;
  uint32_t end;
};

typedef void (*CmgChangeCallback)(void* user, uint32_t nal_index,
                                  uint32_t offset, const uint8_t* data,
                                  uint32_t length);

int cmg_native_decode(const uint8_t* es, size_t es_length,
                      const CmgNal* nals, size_t nal_count,
                      int64_t key_ms, int64_t clock_ms,
                      uint32_t* changed_nals, uint32_t* video_nals,
                      uint32_t* changed_bytes,
                      CmgChangeCallback callback, void* callback_user);

#ifdef __cplusplus
}
#endif

#endif
