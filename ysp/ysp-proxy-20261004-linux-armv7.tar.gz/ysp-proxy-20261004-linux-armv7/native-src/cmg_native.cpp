#include "cmg_native.h"

#include <algorithm>
#include <atomic>
#include <array>
#include <cstdint>
#include <cinttypes>
#include <condition_variable>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <exception>
#include <memory>
#include <mutex>
#include <string>
#include <stdexcept>
#include <thread>
#include <unordered_map>
#include <vector>
#include "generated/cmg.h"
#include "cmg_prerun.inc"

namespace {

constexpr uint32_t kProgramBase = 6309392;
constexpr uint32_t kDynamicBase = 5260816;
constexpr uint32_t kDynamicTopAfterPrerun = 6687984;
constexpr uint32_t kStackTop = 5260816;
constexpr uint32_t kHeapSize = 16777216;
constexpr char kOrigin[] = "https://www.yangshipin.cn";
constexpr char kPlayerConfig[] = "{\"CMGH5player\":{\"VER\":20240531,\"RSA\":\"1\",\"SM2\":\"0\",\"CRC32\":\"1\",\"AES\":\"0\",\"MD5\":\"1\",\"MD5HEX\":\"A73004463239C524F37849F42DD267EF\",\"BTime\":\"2024-05-30-16:25:10\"}}";
constexpr char kLocationHost[] = "www.yangshipin.cn";
constexpr char kLocationHref[] = "https://www.yangshipin.cn/tv/home";
constexpr char kLocationProtocol[] = "https:";
constexpr char kLocationPathname[] = "/tv/home";
constexpr char kDocumentReferrer[] = "https://www.yangshipin.cn/";
constexpr char kNavigatorUserAgent[] = "Mozilla/5.0";
constexpr char kNavigatorLanguage[] = "zh-CN";
constexpr char kNavigatorPlatform[] = "Linux armv7l";
constexpr int kPrimeFunctions[] = {7, 6, 5, 4, 3, 1, 8};

struct EmvalValue {
  enum Kind { Reserved, Global, String, Number, Boolean, Property, TempArray, Opaque };
  Kind kind = Reserved;
  std::string text;
  double number = 0;
  uint32_t object = 0;
  uint32_t key = 0;
  bool live = false;
  uint32_t refcount = 0;
  std::string object_name;  // named global object, e.g. "location"
  std::string property_name;  // resolved property key for Property kind
  std::vector<std::pair<uint32_t, uint32_t>> destructors;  // TempArray: fn, arg
};

struct TypeInfo {
  enum Kind { Unknown, String, WString, Void, MemoryView, Integer, Float, Emval, Bool };
  Kind kind = Unknown;
  uint32_t size = 4;
  bool is_signed = true;
};

struct NativeState;

}  // namespace

namespace {
std::atomic<uint32_t> g_dump_session{0};
thread_local bool g_runtime_thread_initialized = false;
std::once_flag g_runtime_once;
}  // namespace

struct w2c_env {
  wasm_rt_memory_t memory{};
  wasm_rt_funcref_table_t table{};
  uint32_t table_base = 0;
  uint32_t a = 17920;
  uint32_t b = 17904;
  uint32_t c = kStackTop;
  uint32_t d = kProgramBase;
  uint32_t temp_ret0 = 0;
  double clock_ms = 0;
  NativeState* native = nullptr;
  std::array<EmvalValue, 256> handles{};
  std::vector<uint32_t> free_handles;
  uint32_t next_handle = 5;
  std::unordered_map<uint32_t, TypeInfo> types;
  uint32_t last_key_ptr = 0;
  std::vector<uint32_t> pending_fetches;
  std::vector<uint32_t> pending_fetch_callbacks;
};

namespace {

constexpr size_t kSessionLowBytes = 64u * 1024u;
constexpr size_t kSessionHeapSlack = 512u * 1024u;
constexpr size_t kObservePageSize = 4096u;
constexpr size_t kObserveBaseStart =
    (kDynamicBase / kObservePageSize - 1u) * kObservePageSize;
constexpr size_t kObserveBaseEnd = kObserveBaseStart + 4u * kObservePageSize;
constexpr size_t kObserveTailStart =
    (kDynamicTopAfterPrerun / kObservePageSize) * kObservePageSize;
constexpr size_t kObserveTailEnd = kDynamicTopAfterPrerun + 256u * 1024u;


struct SessionSnapshot {
  std::vector<uint8_t> low;
  std::vector<uint8_t> heap;
  size_t heap_start = 0;
  uint32_t g5 = 0, g6 = 0, g7 = 0, g8 = 0, g9 = 0;
  uint32_t table_base = 0, a = 0, b = 0, c = 0, d = 0;
  uint32_t temp_ret0 = 0, last_key_ptr = 0, next_handle = 0;
  double clock_ms = 0;
  std::array<EmvalValue, 256> handles;
  std::vector<uint32_t> free_handles;
  std::unordered_map<uint32_t, TypeInfo> types;
  std::vector<uint32_t> pending_fetches;
  std::vector<uint32_t> pending_fetch_callbacks;
  std::vector<uint8_t> dirty_pages;

  explicit SessionSnapshot(const NativeState& native);

  void capture(const NativeState& native);
  void observe(const NativeState& native);

  void restore(NativeState& native);
};

struct NativeState {
  w2c_env env{};
  w2c_cmg instance{};
  bool initialized = false;
  bool constructors_done = false;
  bool runtime_thread_initialized = false;
  std::unique_ptr<SessionSnapshot> session_snapshot;

  ~NativeState() {
    if (initialized) {
      wasm_rt_free_funcref_table(&env.table);
      wasm_rt_free_memory(&env.memory);
    }
    if (runtime_thread_initialized) {
      wasm_rt_free_thread();
    }
  }
};
inline SessionSnapshot::SessionSnapshot(const NativeState& native) {
  capture(native);
}
inline void SessionSnapshot::capture(const NativeState& native) {
  const size_t memory_size = native.env.memory.size;
  dirty_pages.assign((memory_size + kObservePageSize - 1) / kObservePageSize, 0);
  const size_t low_size = std::min(kSessionLowBytes, memory_size);
  low.assign(native.env.memory.data, native.env.memory.data + low_size);
  heap_start = std::min<size_t>(kDynamicBase, memory_size);
  const size_t heap_end = std::min(memory_size, kDynamicTopAfterPrerun + kSessionHeapSlack);
  if (heap_end > heap_start) {
    heap.assign(native.env.memory.data + heap_start, native.env.memory.data + heap_end);
  }
  g5 = native.instance.w2c_g5;
  g6 = native.instance.w2c_g6;
  g7 = native.instance.w2c_g7;
  g8 = native.instance.w2c_g8;
  g9 = native.instance.w2c_g9;
  table_base = native.env.table_base;
  a = native.env.a;
  b = native.env.b;
  c = native.env.c;
  d = native.env.d;
  temp_ret0 = native.env.temp_ret0;
  last_key_ptr = native.env.last_key_ptr;
  next_handle = native.env.next_handle;
  clock_ms = native.env.clock_ms;
  handles = native.env.handles;
  free_handles = native.env.free_handles;
  types = native.env.types;
  pending_fetches = native.env.pending_fetches;
  pending_fetch_callbacks = native.env.pending_fetch_callbacks;
}
inline void SessionSnapshot::observe(const NativeState& native) {
  std::fill(dirty_pages.begin(), dirty_pages.end(), 0);
  constexpr size_t chunk_size = kObservePageSize;
  const auto overlaps_candidate = [](size_t begin, size_t end) {
    if (begin < kSessionLowBytes && end > 0) return true;
    if (begin < kObserveBaseEnd && end > kObserveBaseStart) return true;
    return begin < kObserveTailEnd && end > kObserveTailStart;
  };
  const auto mark_pages = [&](size_t begin, size_t end) {
    if (begin >= end || dirty_pages.empty()) return;
    const size_t first = begin / kObservePageSize;
    const size_t last = (end - 1) / kObservePageSize;
    const size_t last_page = std::min(last, dirty_pages.size() - 1);
    for (size_t page = std::min(first, last_page); page <= last_page; ++page) {
      dirty_pages[page] = 1;
    }
  };
  const auto observe_region = [&](const uint8_t* current, size_t offset,
                                  const std::vector<uint8_t>& baseline) {
    size_t begin = 0;
    while (begin < baseline.size()) {
      const size_t chunk_end = std::min(baseline.size(), begin + chunk_size);
      const size_t absolute_begin = offset + begin;
      const size_t absolute_end = offset + chunk_end;
      if (overlaps_candidate(absolute_begin, absolute_end) &&
          std::memcmp(current + begin, baseline.data() + begin,
                      chunk_end - begin) != 0) {
        mark_pages(absolute_begin, absolute_end);
      }
      begin = chunk_end;
    }
  };
  observe_region(native.env.memory.data, 0, low);
  if (!heap.empty()) {
    observe_region(native.env.memory.data + heap_start, heap_start, heap);
  }
}
inline void SessionSnapshot::restore(NativeState& native) {
  const size_t memory_size = native.env.memory.size;
  for (size_t page = 0; page < dirty_pages.size(); ++page) {
    if (!dirty_pages[page]) continue;
    const size_t begin = page * kObservePageSize;
    const size_t end = std::min(memory_size, begin + kObservePageSize);
    if (begin < low.size()) {
      const size_t low_end = std::min(end, low.size());
      std::memcpy(native.env.memory.data + begin, low.data() + begin,
                  low_end - begin);
    }
    if (end > heap_start && begin < heap_start + heap.size()) {
      const size_t heap_begin = std::max(begin, heap_start);
      const size_t heap_end = std::min(end, heap_start + heap.size());
      if (heap_begin < heap_end) {
        std::memcpy(native.env.memory.data + heap_begin,
                    heap.data() + (heap_begin - heap_start),
                    heap_end - heap_begin);
      }
    }
  }
  std::fill(dirty_pages.begin(), dirty_pages.end(), 0);
  native.instance.w2c_g5 = g5;
  native.instance.w2c_g6 = g6;
  native.instance.w2c_g7 = g7;
  native.instance.w2c_g8 = g8;
  native.instance.w2c_g9 = g9;
  native.env.table_base = table_base;
  native.env.a = a;
  native.env.b = b;
  native.env.c = c;
  native.env.d = d;
  native.env.temp_ret0 = temp_ret0;
  native.env.last_key_ptr = last_key_ptr;
  native.env.next_handle = next_handle;
  native.env.clock_ms = clock_ms;
  native.env.handles = handles;
  native.env.free_handles = free_handles;
  native.env.types = types;
  native.env.pending_fetches = pending_fetches;
  native.env.pending_fetch_callbacks = pending_fetch_callbacks;
}

class WorkerStatePool {
 public:
  WorkerStatePool() {
    for (auto& state : states_) state.reset(new NativeState);
  }

  size_t acquire() {
    std::unique_lock<std::mutex> lock(mutex_);
    ready_.wait(lock, [this] {
      for (bool used : in_use_) if (!used) return true;
      return false;
    });
    for (size_t i = 0; i < in_use_.size(); ++i) {
      if (!in_use_[i]) {
        in_use_[i] = true;
        return i;
      }
    }
    return 0;
  }

  NativeState* get(size_t slot) { return states_[slot].get(); }

  void release(size_t slot) {
    {
      std::lock_guard<std::mutex> lock(mutex_);
      in_use_[slot] = false;
    }
    ready_.notify_one();
  }

 private:
  std::array<std::unique_ptr<NativeState>, 4> states_;
  std::array<bool, 4> in_use_{};
  std::mutex mutex_;
  std::condition_variable ready_;
};

WorkerStatePool& workerStatePool() {
  static WorkerStatePool pool;
  return pool;
}

thread_local NativeState* g_worker_state = nullptr;

NativeState& state() {
  static NativeState primary;
  if (g_worker_state) return *g_worker_state;
  return primary;
}

void setWorkerState(NativeState* state) {
  g_worker_state = state;
}

uint8_t* memoryPtr(w2c_env* env, uint32_t address) {
  return env->memory.data + address;
}

void dumpNativeMemory(w2c_env* env, const char* name) {
  const char* directory = std::getenv("CMG_NATIVE_DUMP_DIR");
  if (!directory) return;
  const std::string path = std::string(directory) + "/" + name + ".bin";
  std::FILE* file = std::fopen(path.c_str(), "wb");
  if (!file) return;
  std::fwrite(env->memory.data, 1, env->memory.size, file);
  std::fclose(file);
  if (g_dump_session == 0) return;
  const std::string session_path = std::string(directory) + "/" + name + "-" +
                                   std::to_string(g_dump_session) + ".bin";
  file = std::fopen(session_path.c_str(), "wb");
  if (!file) return;
  std::fwrite(env->memory.data, 1, env->memory.size, file);
  std::fclose(file);
}

uint32_t load32(w2c_env* env, uint32_t address) {
  uint32_t value = 0;
  std::memcpy(&value, memoryPtr(env, address), sizeof(value));
  return value;
}

void store32(w2c_env* env, uint32_t address, uint32_t value) {
  std::memcpy(memoryPtr(env, address), &value, sizeof(value));
}

void traceEmvalMemory(const char* tag, w2c_env* env) {
  if (!std::getenv("CMG_NATIVE_IMPORT_TRACE")) return;
  std::printf("native-mem %s m16080=%08x%08x m18008=%08x\n", tag,
              load32(env, 16080), load32(env, 16084), load32(env, 18008));
}


void registerType(w2c_env* env, uint32_t id, TypeInfo::Kind kind,
                  uint32_t size = 4, bool is_signed = true) {
  env->types[id] = TypeInfo{kind, size, is_signed};
}

uint32_t emvalRegister(w2c_env* env, EmvalValue value) {
  if (value.kind == EmvalValue::Reserved) return 1;
  if (value.kind == EmvalValue::Boolean && !value.number) return 4;
  if (value.kind == EmvalValue::Boolean) return 3;
  uint32_t id = 0;
  if (!env->free_handles.empty()) {
    id = env->free_handles.back();
    env->free_handles.pop_back();
  } else {
    id = env->next_handle++;
  }
  if (id >= env->handles.size()) return 1;
  value.live = true;
  value.refcount = 1;
  env->handles[id] = value;
  return id;
}

const EmvalValue* emvalGet(w2c_env* env, uint32_t id) {
  if (id == 0 || id >= env->handles.size()) return nullptr;
  const auto& value = env->handles[id];
  return value.live ? &value : nullptr;
}

void emvalDecref(w2c_env* env, uint32_t id) {
  if (id <= 4 || id >= env->handles.size()) return;
  auto& value = env->handles[id];
  if (!value.live || value.refcount == 0) return;
  if (--value.refcount == 0) {
    value.live = false;
    env->free_handles.push_back(id);
  }
}

// Mirrors the Node reference stub in work/cmg-reference-trace-helper.cjs.
// Returns false when the global/property is not present (JS `undefined`).
bool lookupEnvironment(const std::string& object_name,
                      const std::string& property, std::string* out) {
  if (object_name == "location" || object_name == "self" ||
      object_name == "window" || object_name == "globalThis") {
    if (object_name != "location") {
      // self/window/globalThis expose `location` as a nested object; a direct
      // string property of the global is not part of the reference stub.
      return false;
    }
    if (property == "host" || property == "hostname") {
      *out = kLocationHost;
    } else if (property == "href") {
      *out = kLocationHref;
    } else if (property == "protocol") {
      *out = kLocationProtocol;
    } else if (property == "origin") {
      *out = kOrigin;
    } else if (property == "pathname") {
      *out = kLocationPathname;
    } else {
      return false;
    }
    return true;
  }
  if (object_name == "document") {
    if (property == "referrer" || property == "domain" ||
        property == "cookie" || property == "title" || property == "URL") {
      out->clear();
      if (property == "referrer") *out = kDocumentReferrer;
      else if (property == "domain") *out = kLocationHost;
      else if (property == "URL") *out = kLocationHref;
      return true;
    }
    return false;
  }
  if (object_name == "navigator") {
    if (property == "userAgent") {
      *out = kNavigatorUserAgent;
      return true;
    }
    if (property == "language") {
      *out = kNavigatorLanguage;
      return true;
    }
    if (property == "platform") {
      *out = kNavigatorPlatform;
      return true;
    }
    return false;
  }
  return false;
}

// Resolves a Global/Property chain to a concrete JS value, mirroring
// __emval_get_global -> __emval_get_property -> toWireType.
bool resolveEmvalString(const w2c_env* env, uint32_t id, std::string* out) {
  const EmvalValue* value = emvalGet(const_cast<w2c_env*>(env), id);
  if (!value) return false;
  switch (value->kind) {
    case EmvalValue::String:
    case EmvalValue::Number:
    case EmvalValue::Boolean:
      *out = value->text;
      return true;
    case EmvalValue::Property:
      if (value->object_name.empty()) return false;
      return lookupEnvironment(value->object_name, value->property_name, out);
    default:
      return false;
  }
}

std::string readStdString(w2c_env* env, uint32_t pointer) {
  // C++ side passes a pointer slot; the slot holds the wire object pointer.
  const uint32_t wire = load32(env, pointer);
  const uint32_t length = load32(env, wire);
  std::string value;
  value.reserve(length);
  for (uint32_t i = 0; i < length; ++i) {
    value.push_back(static_cast<char>(*memoryPtr(env, wire + 4 + i)));
  }
  w2c_cmg_Aa(&state().instance, wire);
  return value;
}

uint32_t writeStdString(w2c_env* env, const std::string& value) {
  NativeState& native = state();
  const uint32_t pointer = w2c_cmg_Ea(&native.instance, 4 + value.size() + 1);
  store32(env, pointer, static_cast<uint32_t>(value.size()));
  std::memcpy(memoryPtr(env, pointer + 4), value.data(), value.size());
  *memoryPtr(env, pointer + 4 + value.size()) = 0;
  return pointer;
}

void resetHandles(w2c_env* env) {
  env->free_handles.clear();
  env->next_handle = 5;
  for (auto& handle : env->handles) handle = EmvalValue{};
  env->pending_fetches.clear();
  env->pending_fetch_callbacks.clear();
}

void callMain(NativeState& native) {
  const char* program = std::getenv("CMG_NATIVE_PROGRAM");
  if (!program) program = "./this.program";
  const size_t program_length = std::strlen(program);

  const uint32_t argv = w2c_cmg_Ma(&native.instance, 12);
  const uint32_t program_ptr =
      w2c_cmg_Ma(&native.instance, static_cast<uint32_t>(program_length + 1));
  std::memcpy(memoryPtr(&native.env, program_ptr), program,
              program_length + 1);
  store32(&native.env, argv, program_ptr);
  store32(&native.env, argv + 4, 0);

  const uint32_t stack = w2c_cmg_Ka(&native.instance);
  (void)stack;
  w2c_cmg_Da(&native.instance, 1, argv);
  w2c_cmg_Ja(&native.instance, stack);
}

void initializeState() {
  NativeState& native = state();
  if (native.initialized) return;
  std::call_once(g_runtime_once, [] {
    wasm_rt_init();
    g_runtime_thread_initialized = true;
  });
  if (!g_runtime_thread_initialized) {
    wasm_rt_init_thread();
    g_runtime_thread_initialized = true;
  }
  native.runtime_thread_initialized = true;
  wasm_rt_allocate_memory(&native.env.memory, 256, 1536, false, 65536);
  wasm_rt_allocate_funcref_table(&native.env.table, 560, 560);
  store32(&native.env, 17904, kDynamicBase);
  native.env.native = &native;
  native.env.table_base = 0;
  native.env.a = 17920;
  native.env.b = 17904;
  native.env.c = kStackTop;
  native.env.d = kProgramBase;
  resetHandles(&native.env);
  wasm2c_cmg_instantiate(&native.instance, &native.env);
  native.env.native = &native;
  std::memcpy(memoryPtr(&native.env, native.env.d), kCmgPrerunBytes,
              sizeof(kCmgPrerunBytes));
  for (uint32_t relocation : kCmgPrerunRelocations) {
    const uint32_t address = native.env.d + relocation;
    store32(&native.env, address, load32(&native.env, address) + native.env.d);
  }
  store32(&native.env, 17904, kDynamicTopAfterPrerun);
  native.initialized = true;
  if (!native.constructors_done) {
    w2c_cmg_La(&native.instance);
    callMain(native);
    native.constructors_done = true;
  }
  dumpNativeMemory(&native.env, "after-runtime");
}

std::array<uint8_t, 13> keyBytes(int64_t key_ms) {
  std::array<uint8_t, 13> key{};
  key.fill('0');
  std::string text = std::to_string(key_ms);
  if (text.size() > key.size()) text = text.substr(text.size() - key.size());
  const size_t offset = key.size() - text.size();
  for (size_t i = 0; i < text.size(); ++i) key[offset + i] = static_cast<uint8_t>(text[i]);
  return key;
}

uint32_t allocData(w2c_env* env, const uint8_t* payload, size_t length) {
  NativeState& native = state();
  const uint32_t pointer = w2c_cmg_Ca(&native.instance,
                                      static_cast<uint32_t>(length + 2048));
  std::memset(memoryPtr(env, pointer), 0, length + 2048);
  if (length) std::memcpy(memoryPtr(env, pointer), payload, length);
  std::memcpy(memoryPtr(env, pointer + length), kOrigin, sizeof(kOrigin) - 1);
  return pointer;
}

void freeData(w2c_env* env, uint32_t pointer) {
  (void)env;
  w2c_cmg_Ba(&state().instance, pointer);
}

void completePendingFetches(w2c_env* env) {
  constexpr char kNotFound[] = "Not Found";
  for (uint32_t fetch : env->pending_fetches) {
    const uint32_t url_ptr = load32(env, fetch + 8);
    const char* url = url_ptr ? reinterpret_cast<const char*>(memoryPtr(env, url_ptr)) : nullptr;
    if (!url || !std::strstr(url, "CMGPlayer.json")) continue;
    store32(env, fetch + 40, 4u | (404u << 16));
    std::memcpy(memoryPtr(env, fetch + 44), kNotFound, sizeof(kNotFound));
    env->pending_fetch_callbacks.push_back(fetch);
  }
  env->pending_fetches.clear();
}

void runPendingFetchCallbacks(w2c_env* env) {
  constexpr uint32_t config_length = sizeof(kPlayerConfig) - 1;
  for (uint32_t fetch : env->pending_fetch_callbacks) {
    const uint32_t url_ptr = load32(env, fetch + 8);
    const char* url = url_ptr ? reinterpret_cast<const char*>(memoryPtr(env, url_ptr)) : nullptr;
    if (!url || !std::strstr(url, "CMGPlayer.json")) continue;

    const uint32_t response = w2c_cmg_Ea(&state().instance, config_length);
    std::memcpy(memoryPtr(env, response), kPlayerConfig, config_length);
    store32(env, fetch + 12, response);
    store32(env, fetch + 16, config_length);
    store32(env, fetch + 20, 0);
    store32(env, fetch + 24, 0);
    store32(env, fetch + 28, 0);
    store32(env, fetch + 32, config_length);
    store32(env, fetch + 36, 0);
    store32(env, fetch + 40, 4u | (200u << 16));

    const uint32_t callback = load32(env, fetch + 148);
    if (callback) w2c_cmg_Ha(&state().instance, callback, fetch);
    if (std::getenv("CMG_NATIVE_IMPORT_TRACE")) {
      std::printf("native-fetch-callback fetch=%u callback=%u response=%u\n", fetch, callback, response);
    }
  }
  env->pending_fetch_callbacks.clear();
}

void invokePrime(w2c_env* env, const uint8_t* payload, size_t length,
                 const std::array<uint8_t, 13>& key) {
  using Live = uint32_t (*)(w2c_cmg*, uint32_t, uint32_t, uint32_t, uint32_t);
  static const Live live[] = {
      w2c_cmg_ea, w2c_cmg_fa, w2c_cmg_ga, w2c_cmg_ha, w2c_cmg_ia,
      w2c_cmg_ja, w2c_cmg_ka, w2c_cmg_la, w2c_cmg_ma,
  };
  for (int fn : kPrimeFunctions) {
    const uint32_t data = allocData(env, payload, length);
    const uint32_t key_ptr = w2c_cmg_Ca(&state().instance, 13);
    std::memcpy(memoryPtr(env, key_ptr), key.data(), key.size());
    live[fn](&state().instance, key_ptr, data, static_cast<uint32_t>(length), 25);
    freeData(env, data);
    freeData(env, key_ptr);
  }
}

uint32_t vmpTagFor(const std::array<uint8_t, 13>& key, int64_t clock_ms) {
  NativeState& native = state();
  const uint32_t buffer = w2c_cmg_Ca(&native.instance, 2061);
  std::memset(memoryPtr(&native.env, buffer), 0, 2061);
  std::memcpy(memoryPtr(&native.env, buffer), key.data(), key.size());
  const uint32_t tag = w2c_cmg_da(&native.instance, buffer);
  if (std::getenv("CMG_NATIVE_IMPORT_TRACE")) {
    std::printf("native-update ptr=%u tag=%08x clock=%" PRId64 "\n", buffer, tag, clock_ms);
    std::printf("native-vmp tag=%08x clock=%" PRId64 "\n", tag, clock_ms);
  }
  w2c_cmg_Ba(&native.instance, buffer);
  return tag;
}

std::vector<uint8_t> scheduledFunctions(uint32_t tag) {
  std::vector<uint8_t> functions;
  char text[9];
  std::snprintf(text, sizeof(text), "%08x", tag);
  for (int i = 0; i < 8; ++i) {
    if (text[i] >= '0' && text[i] <= '6') functions.push_back(static_cast<uint8_t>(7 - i));
  }
  functions.push_back(8);
  return functions;
}

void scheduledDecode(w2c_env* env, const uint8_t* payload, size_t length,
                     const std::array<uint8_t, 13>& key, uint32_t tag,
                     uint8_t* output) {
  using Live = uint32_t (*)(w2c_cmg*, uint32_t, uint32_t, uint32_t, uint32_t);
  static const Live live[] = {
      w2c_cmg_ea, w2c_cmg_fa, w2c_cmg_ga, w2c_cmg_ha, w2c_cmg_ia,
      w2c_cmg_ja, w2c_cmg_ka, w2c_cmg_la, w2c_cmg_ma,
  };
  const uint32_t data = allocData(env, payload, length);
  const uint32_t key_ptr = w2c_cmg_Ca(&state().instance, 13);
  std::memcpy(memoryPtr(env, key_ptr), key.data(), key.size());
  state().env.last_key_ptr = key_ptr;
  for (uint8_t fn : scheduledFunctions(tag)) {
    live[fn](&state().instance, key_ptr, data, static_cast<uint32_t>(length), 25);
  }
  std::memcpy(output, memoryPtr(env, data), length);
  freeData(env, data);
  freeData(env, key_ptr);
}

void emitRuns(CmgChangeCallback callback, void* user, uint32_t nal_index,
              const uint8_t* original, const uint8_t* output, size_t length) {
  size_t run_start = 0;
  bool in_run = false;
  for (size_t i = 0; i <= length; ++i) {
    const bool differs = i < length && original[i] != output[i];
    if (differs && !in_run) {
      run_start = i;
      in_run = true;
    } else if (!differs && in_run) {
      if (callback) {
        callback(user, nal_index, static_cast<uint32_t>(run_start),
                 output + run_start, static_cast<uint32_t>(i - run_start));
      }
      in_run = false;
    }
  }
}

bool validNals(const uint8_t* es, size_t es_length, const CmgNal* nals,
               size_t nal_count) {
  if (!es || !nals || nal_count == 0) return false;
  for (size_t i = 0; i < nal_count; ++i) {
    if (nals[i].start > nals[i].end || nals[i].end > es_length) return false;
  }
  return true;
}

}  // namespace

extern "C" {

#define CMG_VOID0(name) void name(w2c_env*) {}
#define CMG_VOID1(name) void name(w2c_env*, uint32_t) { (void)0; }
#define CMG_VOID2(name) void name(w2c_env*, uint32_t, uint32_t) { (void)0; }
#define CMG_VOID3(name) void name(w2c_env*, uint32_t, uint32_t, uint32_t) { (void)0; }
#define CMG_VOID4(name) void name(w2c_env*, uint32_t, uint32_t, uint32_t, uint32_t) { (void)0; }
#define CMG_VOID5(name) void name(w2c_env*, uint32_t, uint32_t, uint32_t, uint32_t, uint32_t) { (void)0; }
#define CMG_VOID7(name) void name(w2c_env*, uint32_t, uint32_t, uint32_t, uint32_t, uint32_t, uint32_t, uint32_t) { (void)0; }
#define CMG_VOID6(name) void name(w2c_env*, uint32_t, uint32_t, uint32_t, uint32_t, uint32_t, uint32_t) { (void)0; }
#define CMG_U32_0(name) uint32_t name(w2c_env*) { return 0; }
#define CMG_U32_1(name) uint32_t name(w2c_env*, uint32_t) { return 0; }
#define CMG_U32_2(name) uint32_t name(w2c_env*, uint32_t, uint32_t) { return 0; }
#define CMG_U32_3(name) uint32_t name(w2c_env*, uint32_t, uint32_t, uint32_t) { return 0; }
#define CMG_U32_4(name) uint32_t name(w2c_env*, uint32_t, uint32_t, uint32_t, uint32_t) { return 0; }
#define CMG_U32_5(name) uint32_t name(w2c_env*, uint32_t, uint32_t, uint32_t, uint32_t, uint32_t) { return 0; }

u32* w2c_env_0x5F_table_base(w2c_env* env) { return &env->table_base; }
u32* w2c_env_a(w2c_env* env) { return &env->a; }
u32* w2c_env_b(w2c_env* env) { return &env->b; }
u32* w2c_env_c(w2c_env* env) { return &env->c; }
u32* w2c_env_d(w2c_env* env) { return &env->d; }
wasm_rt_memory_t* w2c_env_memory(w2c_env* env) { return &env->memory; }
wasm_rt_funcref_table_t* w2c_env_table(w2c_env* env) { return &env->table; }

CMG_VOID3(w2c_env_0x24)
CMG_VOID0(w2c_env_A)

uint32_t w2c_env_B(w2c_env* env, uint32_t type, uint32_t pointer) {
  const auto found = env->types.find(type);
  EmvalValue value;
  if (found != env->types.end() && found->second.kind == TypeInfo::String) {
    value.kind = EmvalValue::String;
    value.text = readStdString(env, pointer);
  } else if (found != env->types.end() && found->second.kind == TypeInfo::Integer) {
    value.kind = EmvalValue::Number;
    value.number = static_cast<double>(static_cast<int32_t>(load32(env, pointer)));
  } else if (found != env->types.end() && found->second.kind == TypeInfo::Bool) {
    value.kind = EmvalValue::Boolean;
    value.number = load32(env, pointer) != 0;
  } else {
    value.kind = EmvalValue::Opaque;
    value.number = load32(env, pointer);
  }
  const uint32_t handle = emvalRegister(env, value);
  if (std::getenv("CMG_NATIVE_IMPORT_TRACE")) {
    std::printf("native-import B type=%u ptr=%u text=%s -> %u\n", type, pointer,
                value.text.c_str(), handle);
  }
  traceEmvalMemory("B", env);
  return handle;
}

void w2c_env_C(w2c_env* env, uint32_t handle) {
  if (std::getenv("CMG_NATIVE_IMPORT_TRACE")) std::printf("native-import C %u\n", handle);
  if (const EmvalValue* value = emvalGet(env, handle)) {
    if (value->kind == EmvalValue::TempArray) {
      for (const auto& destructor : value->destructors) {
        if (destructor.first == 1) w2c_cmg_Aa(&state().instance, destructor.second);
      }
    }
  }
  emvalDecref(env, handle);
  traceEmvalMemory("C", env);
}

uint32_t w2c_env_D(w2c_env* env, uint32_t object, uint32_t key) {
  EmvalValue value;
  value.kind = EmvalValue::Property;
  value.object = object;
  value.key = key;
  if (const EmvalValue* parent = emvalGet(env, object)) {
    if (parent->kind == EmvalValue::Global) value.object_name = parent->object_name;
  }
  if (const EmvalValue* name = emvalGet(env, key)) value.property_name = name->text;
  const uint32_t handle = emvalRegister(env, value);
  if (std::getenv("CMG_NATIVE_IMPORT_TRACE")) {
    std::printf("native-import D obj=%u key=%u objname=%s prop=%s -> %u\n",
                object, key, value.object_name.c_str(), value.property_name.c_str(), handle);
  }
  traceEmvalMemory("D", env);
  return handle;
}

uint32_t w2c_env_E(w2c_env* env, uint32_t name_ptr) {
  EmvalValue value;
  value.kind = EmvalValue::Global;
  const char* name = reinterpret_cast<const char*>(memoryPtr(env, name_ptr));
  value.object_name = name ? name : "";
  if (std::getenv("CMG_NATIVE_IMPORT_TRACE")) {
    std::printf("native-import E ptr=%u name=%s\n", name_ptr, value.object_name.c_str());
  }
  traceEmvalMemory("E", env);
  return emvalRegister(env, value);
}

void w2c_env_F(w2c_env* env, uint32_t handle) {
  if (std::getenv("CMG_NATIVE_IMPORT_TRACE")) std::printf("native-import F %u\n", handle);
  emvalDecref(env, handle);
  traceEmvalMemory("F", env);
}

double w2c_env_G(w2c_env* env, uint32_t handle, uint32_t type, uint32_t result_ptr) {
  const EmvalValue* value = emvalGet(env, handle);
  EmvalValue temp;
  temp.kind = EmvalValue::TempArray;
  const uint32_t temp_handle = emvalRegister(env, temp);
  store32(env, result_ptr, temp_handle);
  traceEmvalMemory("G-in", env);
  if (!value) return 0;
  const auto found = env->types.find(type);
  if (found != env->types.end() && found->second.kind == TypeInfo::String) {
    std::string resolved;
    if (value->kind == EmvalValue::String || value->kind == EmvalValue::Number ||
        value->kind == EmvalValue::Boolean) {
      resolved = value->text;
    } else {
      resolveEmvalString(env, handle, &resolved);
    }
    if (std::getenv("CMG_NATIVE_IMPORT_TRACE")) {
      std::printf("native-import G handle=%u type=%u resolved=%s\n", handle, type,
                  resolved.c_str());
    }
    const uint32_t ptr = writeStdString(env, resolved);
    if (EmvalValue* slot = &env->handles[temp_handle]) {
      slot->destructors.emplace_back(1, ptr);
    }
    traceEmvalMemory("G-str", env);
    return static_cast<double>(ptr);
  }
  traceEmvalMemory("G-num", env);
  return value->number;
}

CMG_VOID1(w2c_env_H)
CMG_U32_2(w2c_env_I)
void w2c_env_J(w2c_env* env, uint32_t type, uint32_t name) {
  (void)name;
  registerType(env, type, TypeInfo::Void);
}
void w2c_env_K(w2c_env* env, uint32_t type, uint32_t size, uint32_t name) {
  (void)name;
  registerType(env, type, TypeInfo::WString, size);
}
void w2c_env_L(w2c_env* env, uint32_t type, uint32_t name) {
  (void)name;
  registerType(env, type, TypeInfo::String);
}
void w2c_env_M(w2c_env* env, uint32_t type, uint32_t kind, uint32_t name) {
  (void)kind;
  (void)name;
  registerType(env, type, TypeInfo::MemoryView);
}
void w2c_env_N(w2c_env* env, uint32_t type, uint32_t name, uint32_t size,
                uint32_t minimum, uint32_t) {
  (void)name;
  registerType(env, type, TypeInfo::Integer, size, static_cast<int32_t>(minimum) < 0);
}
void w2c_env_O(w2c_env* env, uint32_t type, uint32_t name, uint32_t size) {
  (void)name;
  registerType(env, type, TypeInfo::Float, size);
}
void w2c_env_P(w2c_env* env, uint32_t type, uint32_t name) {
  (void)name;
  registerType(env, type, TypeInfo::Emval);
}
void w2c_env_Q(w2c_env* env, uint32_t type, uint32_t name, uint32_t size,
                uint32_t, uint32_t) {
  (void)name;
  registerType(env, type, TypeInfo::Bool, size);
}
CMG_U32_2(w2c_env_R)
CMG_U32_2(w2c_env_S)
CMG_U32_2(w2c_env_T)
CMG_VOID1(w2c_env_U)
CMG_U32_0(w2c_env_V)
CMG_U32_1(w2c_env_W)
CMG_VOID7(w2c_env_X)
CMG_VOID6(w2c_env_Y)
CMG_VOID5(w2c_env_Z)
CMG_VOID4(w2c_env_0x5F)
CMG_VOID1(w2c_env_aa)

uint32_t w2c_env_e(w2c_env* env) { return env->temp_ret0; }
void w2c_env_f(w2c_env* env, uint32_t value) { env->temp_ret0 = value; }
uint32_t w2c_env_g(w2c_env* env, uint32_t timeval_ptr, uint32_t) {
  const int64_t ms = static_cast<int64_t>(env->clock_ms);
  store32(env, timeval_ptr, static_cast<uint32_t>(ms / 1000));
  store32(env, timeval_ptr + 4, static_cast<uint32_t>((ms % 1000) * 1000));
  if (std::getenv("CMG_NATIVE_IMPORT_TRACE")) {
    std::printf("native-import g ptr=%u sec=%u usec=%u\n", timeval_ptr,
                load32(env, timeval_ptr), load32(env, timeval_ptr + 4));
  }
  return 0;
}
CMG_VOID5(w2c_env_h)

double w2c_env_i(w2c_env* env) {
  if (std::getenv("CMG_NATIVE_IMPORT_TRACE")) {
    std::printf("native-import i %.17g\n", env->clock_ms);
  }
  return env->clock_ms;
}

CMG_VOID0(w2c_env_j)
CMG_VOID2(w2c_env_k)
CMG_VOID1(w2c_env_l)
CMG_U32_5(w2c_env_m)
CMG_U32_4(w2c_env_n)
CMG_U32_1(w2c_env_o)
CMG_U32_3(w2c_env_p)
CMG_VOID0(w2c_env_q)
void w2c_env_r(w2c_env* env, uint32_t fetch) {
  env->pending_fetches.push_back(fetch);
  if (std::getenv("CMG_NATIVE_IMPORT_TRACE")) {
    const uint32_t url_ptr = load32(env, fetch + 8);
    const char* url = url_ptr ? reinterpret_cast<const char*>(memoryPtr(env, url_ptr)) : "";
    std::printf("native-import r fetch=%u url_ptr=%u url=%s attrs=%u\n", fetch,
                url_ptr, url, load32(env, fetch + 164));
  }
}
CMG_U32_1(w2c_env_s)

uint32_t w2c_env_t(w2c_env* env, uint32_t destination, uint32_t source,
                   uint32_t length) {
  std::memmove(memoryPtr(env, destination), memoryPtr(env, source), length);
  return 0;
}

CMG_VOID2(w2c_env_u)
uint32_t w2c_env_v(w2c_env*) {
  if (std::getenv("CMG_NATIVE_IMPORT_TRACE")) std::printf("native-import v 1\n");
  return 1;
}
uint32_t w2c_env_w(w2c_env* env) {
  const uint32_t size = static_cast<uint32_t>(env->memory.size);
  if (std::getenv("CMG_NATIVE_IMPORT_TRACE")) std::printf("native-import w %u\n", size);
  return size;
}
CMG_U32_3(w2c_env_x)
uint32_t w2c_env_y(w2c_env*, uint32_t, uint32_t, double, uint32_t, uint32_t,
                   uint32_t, uint32_t) { return 0; }

uint32_t w2c_env_z(w2c_env* env, uint32_t value_ptr, uint32_t expression_ptr) {
  const char* z_expr = reinterpret_cast<const char*>(memoryPtr(env, expression_ptr));
  if (std::getenv("CMG_NATIVE_IMPORT_TRACE")) {
    std::printf("native-import z value=%u expr=%s\n", value_ptr, z_expr ? z_expr : "");
  }
  if (std::getenv("CMG_NATIVE_Z_TRACE")) {
    const uint32_t stack = state().instance.w2c_g6;
    std::printf("native-z value=%u expr_ptr=%u expr=%s g6=%u frame=%u,%u,%u,%u\n",
                value_ptr, expression_ptr,
                reinterpret_cast<const char*>(memoryPtr(env, expression_ptr)),
                stack, load32(env, stack), load32(env, stack + 4),
                load32(env, stack + 8), load32(env, stack + 12));
  }
  const char* expression = reinterpret_cast<const char*>(memoryPtr(env, expression_ptr));
  const char* result = nullptr;
  if (std::strcmp(expression, "self.location.host") == 0) {
    result = kLocationHost;
  } else if (std::strcmp(expression, "self.location.href") == 0) {
    result = kLocationHref;
  } else if (std::strcmp(expression, "self.location.protocol") == 0) {
    result = kLocationProtocol;
  }
  if (!result) return 0;
  const uint32_t length = static_cast<uint32_t>(std::strlen(result) + 1);
  const uint32_t output = w2c_cmg_Ea(&state().instance, length);
  if (std::getenv("CMG_NATIVE_Z_TRACE")) {
    std::printf("native-z output=%u expr=%s\n", output, expression);
  }
  std::memcpy(memoryPtr(env, output), result, length);
  if (std::getenv("CMG_NATIVE_IMPORT_TRACE")) {
    std::printf("native-import z-output ptr=%u expr=%s\n", output, z_expr ? z_expr : "");
  }
  return output;
}

}  // extern "C"

static int decodeNalsSequential(const uint8_t* es, size_t es_length,
                      const CmgNal* nals, size_t nal_count,
                      int64_t key_ms, int64_t clock_ms,
                      uint32_t* changed_nals, uint32_t* video_nals,
                      uint32_t* changed_bytes,
                      CmgChangeCallback callback, void* callback_user,
                      bool reset_session) {
  if (changed_nals) *changed_nals = 0;
  if (video_nals) *video_nals = 0;
  if (changed_bytes) *changed_bytes = 0;
  if (!validNals(es, es_length, nals, nal_count)) return 1;
  if (key_ms < 0 || key_ms > 9999999999999LL) return 2;
  ++g_dump_session;
  const auto phase_start = std::chrono::steady_clock::now();
  const auto elapsed_us = [](const std::chrono::steady_clock::time_point& start) {
    return std::chrono::duration_cast<std::chrono::microseconds>(
               std::chrono::steady_clock::now() - start).count();
  };

  if (const char* init_clock = std::getenv("CMG_NATIVE_INIT_CLOCK")) {
    state().env.clock_ms = std::strtod(init_clock, nullptr);
  }
  initializeState();
  NativeState& native = state();
  native.env.clock_ms = static_cast<double>(clock_ms);
  const auto key = keyBytes(key_ms);
  auto setup_done = phase_start;
  auto prime_done = phase_start;
  std::vector<uint8_t> dirty_baseline;
  const bool dirty_trace = reset_session && g_dump_session == 1 &&
                           std::getenv("CMG_NATIVE_DIRTY_TRACE");
  if (!reset_session && native.session_snapshot) {
    native.session_snapshot->restore(native);
    setup_done = prime_done = std::chrono::steady_clock::now();
  } else if (reset_session || !native.session_snapshot) {
  native.env.temp_ret0 = 0;
  dumpNativeMemory(&native.env, "before-uninit");
  resetHandles(&native.env);

  native.env.last_key_ptr = 0;
  for (int i = 0; i < 4; ++i) {
    w2c_cmg_ca(&native.instance, 0);
    dumpNativeMemory(&native.env, (std::string("after-uninit-") + std::to_string(i + 1)).c_str());
  }

  const uint32_t config = w2c_cmg_Ca(&native.instance, 2048);
  std::memset(memoryPtr(&native.env, config), 0, 2048);
  std::memcpy(memoryPtr(&native.env, config), key.data(), key.size());
  if (std::getenv("CMG_NATIVE_IMPORT_TRACE")) {
    std::printf("native-config ptr=%u key0=%02x key12=%02x\n", config,
                *memoryPtr(&native.env, config), *memoryPtr(&native.env, config + 12));
  }
  if (std::getenv("CMG_NATIVE_IMPORT_TRACE")) {
    std::printf("native-pre-dump ptr=%u b0=%02x b12=%02x\n", config,
                *memoryPtr(&native.env, config), *memoryPtr(&native.env, config + 12));
  }
  dumpNativeMemory(&native.env, "before-init");
    if (std::getenv("CMG_NATIVE_IMPORT_TRACE")) {
      std::printf("native-post-dump ptr=%u b0=%02x b12=%02x\n", config,
                  *memoryPtr(&native.env, config), *memoryPtr(&native.env, config + 12));
    }
    if (std::getenv("CMG_NATIVE_IMPORT_TRACE")) {
      std::printf("native-stack before-init g6=%u\n", native.instance.w2c_g6);
    }
    w2c_cmg_ba(&native.instance, config);
  dumpNativeMemory(&native.env, "after-init");
  if (const char* config_out = std::getenv("CMG_NATIVE_CONFIG_OUT")) {
    std::FILE* file = std::fopen(config_out, "wb");
    if (file) { std::fwrite(memoryPtr(&native.env, config), 1, 2048, file); std::fclose(file); }
  }
  w2c_cmg_Ba(&native.instance, config);
  completePendingFetches(&native.env);
  setup_done = std::chrono::steady_clock::now();

  const uint8_t* sps = nullptr;
  size_t sps_length = 0;
  for (size_t i = 0; i < nal_count; ++i) {
    if (nals[i].type == 7) {
      sps = es + nals[i].start;
      sps_length = nals[i].end - nals[i].start;
      break;
    }
  }
  if (sps) invokePrime(&native.env, sps, sps_length, key);
  prime_done = std::chrono::steady_clock::now();
  dumpNativeMemory(&native.env, "after-prime");
  native.session_snapshot.reset(new SessionSnapshot(native));
  if (dirty_trace) {
    dirty_baseline.assign(native.env.memory.data,
                          native.env.memory.data + native.env.memory.size);
  }
  }

  uint32_t local_changed_nals = 0;
  uint32_t local_video_nals = 0;
  uint32_t local_changed_bytes = 0;
  int64_t update_us = 0, decode_us = 0, emit_us = 0, count_us = 0;
  for (size_t nal_index = 0; nal_index < nal_count; ++nal_index) {
    const CmgNal& nal = nals[nal_index];
    const auto update_start = std::chrono::steady_clock::now();
    const uint32_t tag = vmpTagFor(key, clock_ms);
    update_us += elapsed_us(update_start);
    if (nal.type != 1 && nal.type != 5 && nal.type != 7) continue;
    const uint8_t* input = es + nal.start;
    const size_t length = nal.end - nal.start;
    std::vector<uint8_t> output(length);
    const auto decode_start = std::chrono::steady_clock::now();
    scheduledDecode(&native.env, input, length, key, tag, output.data());
    decode_us += elapsed_us(decode_start);
    const auto emit_start = std::chrono::steady_clock::now();
    emitRuns(callback, callback_user, static_cast<uint32_t>(nal_index),
             input, output.data(), length);
    emit_us += elapsed_us(emit_start);
    const auto count_start = std::chrono::steady_clock::now();
    if (nal.type == 1 || nal.type == 5) {
      ++local_video_nals;
      bool differs = false;
      for (size_t i = 0; i < length; ++i) {
        if (input[i] != output[i]) {
          ++local_changed_bytes;
          differs = true;
        }
      }
      if (differs) ++local_changed_nals;
    }
    count_us += elapsed_us(count_start);
  }
  dumpNativeMemory(&native.env, "after-decode");
  runPendingFetchCallbacks(&native.env);
  if (native.session_snapshot) native.session_snapshot->observe(native);
  if (!dirty_baseline.empty()) {
    size_t dirty_bytes = 0;
    std::array<uint64_t, 64> bins{};
    for (size_t i = 0; i <= dirty_baseline.size(); ++i) {
      const bool differs = i < dirty_baseline.size() &&
          dirty_baseline[i] != native.env.memory.data[i];
      if (differs) ++dirty_bytes;
      if (differs) ++bins[i / (256u * 1024u)];
    }
    for (size_t i = 0; i < bins.size(); ++i) {
      if (bins[i]) std::fprintf(stderr, "native-dirty-bin=%zu bytes=%" PRIu64 "\n", i, bins[i]);
    }
    std::fprintf(stderr, "native-dirty-total=%zu\n", dirty_bytes);
  }
  if (std::getenv("CMG_NATIVE_PHASE_TIMING")) {
    std::fprintf(stderr,
                 "native-phase total=%lldus setup=%lldus prime=%lldus update=%lldus "
                 "decode=%lldus emit=%lldus count=%lldus\n",
                 static_cast<long long>(elapsed_us(phase_start)),
                 static_cast<long long>(std::chrono::duration_cast<std::chrono::microseconds>(setup_done - phase_start).count()),
                 static_cast<long long>(std::chrono::duration_cast<std::chrono::microseconds>(prime_done - setup_done).count()),
                 static_cast<long long>(update_us), static_cast<long long>(decode_us),
                 static_cast<long long>(emit_us), static_cast<long long>(count_us));
  }
  dumpNativeMemory(&native.env, "after-fetch-callback");

  if (changed_nals) *changed_nals = local_changed_nals;
  if (video_nals) *video_nals = local_video_nals;
  if (changed_bytes) *changed_bytes = local_changed_bytes;
  const bool complete = local_video_nals > 0 &&
                        local_changed_nals == local_video_nals &&
                        local_changed_bytes > 0;
  return complete ? 0 : 3;
}

namespace {

struct NalGroup {
  std::vector<CmgNal> nals;
  std::vector<uint32_t> original_index;
};

struct PackedBytes {
  std::vector<uint8_t> bytes;
};

struct PackedCollector {
  PackedBytes* packed;
  const std::vector<uint32_t>* original_index;
};

void collectPacked(void* user, uint32_t nal_index, uint32_t offset,
                   const uint8_t* data, uint32_t length) {
  auto* collector = static_cast<PackedCollector*>(user);
  if (!collector->packed) return;
  if (nal_index >= collector->original_index->size()) {
    throw std::runtime_error("group callback NAL index out of range");
  }
  const uint32_t global_index = (*collector->original_index)[nal_index];
  uint8_t header[12];
  for (int i = 0; i < 4; ++i) header[i] = static_cast<uint8_t>(global_index >> (8 * i));
  for (int i = 0; i < 4; ++i) header[4 + i] = static_cast<uint8_t>(offset >> (8 * i));
  for (int i = 0; i < 4; ++i) header[8 + i] = static_cast<uint8_t>(length >> (8 * i));
  auto& bytes = collector->packed->bytes;
  bytes.insert(bytes.end(), header, header + sizeof(header));
  bytes.insert(bytes.end(), data, data + length);
}

std::vector<NalGroup> splitNalGroups(const CmgNal* nals, size_t nal_count) {
  std::vector<NalGroup> groups;
  size_t first_sps = nal_count;
  for (size_t i = 0; i < nal_count; ++i) {
    if (nals[i].type == 7) {
      first_sps = i;
      break;
    }
  }
  if (first_sps == nal_count) first_sps = nal_count;

  auto append = [&](size_t begin, size_t end) {
    if (begin >= end) return;
    NalGroup group;
    group.nals.reserve(end - begin);
    group.original_index.reserve(end - begin);
    for (size_t i = begin; i < end; ++i) {
      group.nals.push_back(nals[i]);
      group.original_index.push_back(static_cast<uint32_t>(i));
    }
    groups.push_back(std::move(group));
  };

  if (first_sps == nal_count) {
    append(0, nal_count);
    return groups;
  }

  size_t begin = 0;
  for (size_t sps = first_sps + 1; sps < nal_count; ++sps) {
    if (nals[sps].type != 7) continue;
    append(begin, sps);
    begin = sps;
  }
  append(begin, nal_count);
  return groups;
}

struct GroupResult {
  int rc = 0;
  uint32_t changed_nals = 0;
  uint32_t video_nals = 0;
  uint32_t changed_bytes = 0;
  PackedBytes packed;
  std::exception_ptr error;
};

void forwardPacked(const PackedBytes& packed, CmgChangeCallback callback,
                   void* callback_user) {
  if (!callback) return;
  for (size_t pos = 0; pos < packed.bytes.size();) {
    if (pos + 12 > packed.bytes.size()) throw std::runtime_error("short packed header");
    const auto read32 = [&](size_t offset) {
      uint32_t value = 0;
      for (int i = 0; i < 4; ++i) value |= static_cast<uint32_t>(packed.bytes[offset + i]) << (8 * i);
      return value;
    };
    const uint32_t nal_index = read32(pos);
    const uint32_t offset = read32(pos + 4);
    const uint32_t length = read32(pos + 8);
    const size_t end = pos + 12 + length;
    if (end > packed.bytes.size()) throw std::runtime_error("short packed record");
    callback(callback_user, nal_index, offset, packed.bytes.data() + pos + 12, length);
    pos = end;
  }
}

}  // namespace

extern "C" int cmg_native_decode(const uint8_t* es, size_t es_length,
                                 const CmgNal* nals, size_t nal_count,
                                 int64_t key_ms, int64_t clock_ms,
                                 uint32_t* changed_nals, uint32_t* video_nals,
                                 uint32_t* changed_bytes,
                                 CmgChangeCallback callback, void* callback_user) {
  if (changed_nals) *changed_nals = 0;
  if (video_nals) *video_nals = 0;
  if (changed_bytes) *changed_bytes = 0;
  if (!validNals(es, es_length, nals, nal_count)) return 1;
  if (key_ms < 0 || key_ms > 9999999999999LL) return 2;
  if (std::getenv("CMG_NATIVE_SEQUENTIAL")) {
    return decodeNalsSequential(es, es_length, nals, nal_count, key_ms, clock_ms,
                                changed_nals, video_nals, changed_bytes,
                                callback, callback_user, true);
  }

  auto groups = splitNalGroups(nals, nal_count);
  if (groups.size() == 1) {
    return decodeNalsSequential(es, es_length, groups[0].nals.data(),
                                groups[0].nals.size(), key_ms, clock_ms,
                                changed_nals, video_nals, changed_bytes,
                                callback, callback_user, true);
  }

  std::vector<GroupResult> results(groups.size());
  std::atomic<size_t> next_group{0};
  std::atomic<bool> failed{false};
  unsigned worker_count = std::thread::hardware_concurrency();
  if (worker_count == 0) worker_count = 4;
  if (const char* raw = std::getenv("CMG_NATIVE_THREADS")) {
    const long requested = std::strtol(raw, nullptr, 10);
    if (requested >= 0 && requested <= 4) worker_count = static_cast<unsigned>(requested);
  }
  worker_count = std::min<unsigned>(worker_count, 4);
  worker_count = static_cast<unsigned>(std::min<size_t>(worker_count, groups.size()));
  std::vector<size_t> state_slots;
  state_slots.reserve(worker_count);
  for (unsigned i = 0; i < worker_count; ++i) state_slots.push_back(workerStatePool().acquire());
  const char* reuse_raw = std::getenv("CMG_NATIVE_REUSE_SESSION");
  const bool reuse_sessions = !reuse_raw || std::strcmp(reuse_raw, "0") != 0;

  if (worker_count == 0) {
    bool reset_session = true;
    while (!failed.load(std::memory_order_relaxed)) {
      const size_t group_index = next_group.fetch_add(1, std::memory_order_relaxed);
      if (group_index >= groups.size()) break;
      auto& result = results[group_index];
      const auto& group = groups[group_index];
      PackedCollector collector{&result.packed, &group.original_index};
      try {
        result.rc = decodeNalsSequential(
            es, es_length, group.nals.data(), group.nals.size(), key_ms, clock_ms,
            &result.changed_nals, &result.video_nals, &result.changed_bytes,
            collectPacked, &collector, reuse_sessions ? reset_session : true);
        reset_session = false;
      } catch (...) {
        result.error = std::current_exception();
        failed.store(true, std::memory_order_relaxed);
      }
    }
  }
  if (worker_count != 0) {
  std::vector<std::thread> workers;
  workers.reserve(worker_count);
  for (unsigned worker = 0; worker < worker_count; ++worker) {
    workers.emplace_back([&, worker] {
      setWorkerState(workerStatePool().get(state_slots[worker]));
      bool reset_session = true;
      while (!failed.load(std::memory_order_relaxed)) {
        const size_t group_index = next_group.fetch_add(1, std::memory_order_relaxed);
        if (group_index >= groups.size()) break;
        auto& result = results[group_index];
        const auto& group = groups[group_index];
        PackedCollector collector{&result.packed, &group.original_index};
        try {
          result.rc = decodeNalsSequential(
              es, es_length, group.nals.data(), group.nals.size(), key_ms, clock_ms,
              &result.changed_nals, &result.video_nals, &result.changed_bytes,
              collectPacked, &collector, reuse_sessions ? reset_session : true);
          reset_session = false;
          if (result.rc != 0 && result.rc != 3) failed.store(true, std::memory_order_relaxed);
        } catch (...) {
          result.error = std::current_exception();
          failed.store(true, std::memory_order_relaxed);
        }
      }
    });
  }
  for (auto& worker : workers) worker.join();
  }
  for (size_t slot : state_slots) workerStatePool().release(slot);

  PackedBytes merged;
  uint32_t total_changed_nals = 0;
  uint32_t total_video_nals = 0;
  uint32_t total_changed_bytes = 0;
  for (auto& result : results) {
    if (result.error) std::rethrow_exception(result.error);
    if (result.rc != 0 && result.rc != 3) return result.rc;
    total_changed_nals += result.changed_nals;
    total_video_nals += result.video_nals;
    total_changed_bytes += result.changed_bytes;
    merged.bytes.insert(merged.bytes.end(), result.packed.bytes.begin(), result.packed.bytes.end());
  }

  try {
    forwardPacked(merged, callback, callback_user);
  } catch (...) {
    return 1;
  }
  if (changed_nals) *changed_nals = total_changed_nals;
  if (video_nals) *video_nals = total_video_nals;
  if (changed_bytes) *changed_bytes = total_changed_bytes;
  const bool complete = total_video_nals > 0 &&
                        total_changed_nals == total_video_nals &&
                        total_changed_bytes > 0;
  return complete ? 0 : 3;
}
